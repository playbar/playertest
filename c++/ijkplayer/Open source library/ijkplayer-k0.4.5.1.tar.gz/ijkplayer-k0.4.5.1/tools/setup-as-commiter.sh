#! /usr/bin/env bash

git remote add gitcafe git@gitcafe.com:bbcallen/ijkplayer.git
git remote add oschina git@git.oschina.net:bbcallen/ijkplayer.git
git remote add csdn git@code.csdn.net:bbcallen/ijkplayer.git
git fetch --all

