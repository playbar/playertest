package android.media;

@SimpleCClassName
@MinApi(23)
public class PlaybackParams {
    public PlaybackParams setSpeed(float speed);
}
