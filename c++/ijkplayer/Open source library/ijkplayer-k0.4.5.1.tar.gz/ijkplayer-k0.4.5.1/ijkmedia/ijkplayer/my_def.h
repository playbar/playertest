#ifndef MY_DEF_H
#define MY_DEF_H


void my_set_out_size(int out_width, int out_height);

int my_calc_crop_size(int in_width, int in_height, int* crop_width, int* crop_height);




#endif