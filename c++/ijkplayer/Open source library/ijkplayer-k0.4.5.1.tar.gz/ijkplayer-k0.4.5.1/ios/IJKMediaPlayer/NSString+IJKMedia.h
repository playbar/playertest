//
//  NSString+IJKMedia.h
//  IJKMediaPlayer
//
//  Created by Zhang Rui on 15/12/15.
//  Copyright © 2015年 bilibili. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (IJKMedia)

- (BOOL) ijk_isIpv4;

@end
